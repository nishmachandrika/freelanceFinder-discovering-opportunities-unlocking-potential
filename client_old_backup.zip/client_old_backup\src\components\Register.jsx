import React, { useContext, useState } from 'react';
import { GeneralContext } from 'public/src/context/GeneralContext';

const Register = ({ setAuthType }) => {
  const { setUsername, setEmail, setPassword, setUsertype, register, loading, setError } = useContext(GeneralContext);

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!setUsername || !setEmail || !setPassword || !setUsertype || !register) {
      setError('Context setup is incomplete. Check GeneralContext.');
      return;
    }
    if (!setUsername.trim() || !setEmail.trim() || !setPassword.trim() || !setUsertype) {
      setError('All fields are required.');
      return;
    }
    try {
      await register();
    } catch (error) {
      setError('Registration failed. Please try again.');
    }
  }

  return (
    <form className="authForm" onSubmit={handleRegister}>
      <h2>Register</h2>
      <div className="form-floating mb-3 authFormInputs">
        <input type="text" className="form-control" id="floatingInput" placeholder="username" onChange={(e) => setUsername(e.target.value)} />
        <label htmlFor="floatingInput">Username</label>
      </div>
      <div className="form-floating mb-3 authFormInputs">
        <input type="email" className="form-control" id="floatingEmail" placeholder="name@example.com" onChange={(e) => setEmail(e.target.value)} />
        <label htmlFor="floatingEmail">Email address</label>
      </div>
      <div className="form-floating mb-3 authFormInputs">
        <input type="password" className="form-control" id="floatingPassword" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
        <label htmlFor="floatingPassword">Password</label>
      </div>
      <select className="form-select form-select-lg mb-3" aria-label=".form-select-lg example" onChange={(e) => setUsertype(e.target.value)} value={setUsertype || ''}>
        <option value="">User type</option>
        <option value="freelancer">Freelancer</option>
        <option value="client">Client</option>
        <option value="admin">Admin</option>
      </select>
      <button type="submit" className="btn btn-primary" disabled={loading}>
        {loading ? 'Signing up...' : 'Sign up'}
      </button>
      {setError && <p style={{ color: 'red' }}>{setError}</p>}
      <p>Already registered? <span onClick={() => setAuthType('login')}>Login</span></p>
    </form>
  );
}

export default Register;